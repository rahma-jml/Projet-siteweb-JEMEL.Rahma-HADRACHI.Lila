document.addEventListener('DOMContentLoaded', function () {


  const pastillesAccueil = document.querySelectorAll('.hero-choix-btn');
  const messageAccueil = document.getElementById('hero-message');

  if (pastillesAccueil.length && messageAccueil) {

    function choisirPastille(bouton) {
      pastillesAccueil.forEach(function (pastille) {
        const selectionnee = pastille === bouton;
        pastille.classList.toggle('actif', selectionnee);
        pastille.setAttribute('aria-pressed', String(selectionnee));
      });
      messageAccueil.textContent = bouton.dataset.message;
    }

    pastillesAccueil.forEach(function (bouton) {
      bouton.addEventListener('click', function () {
        choisirPastille(bouton);
      });
    });

    choisirPastille(pastillesAccueil[0]);
  }


 

  const boutonMenu = document.querySelector('.menu-bouton');
  const navigation = document.querySelector('nav');

  if (boutonMenu && navigation) {

   
    boutonMenu.addEventListener('click', function () {
      const ouvert = navigation.classList.toggle('ouvert');
      boutonMenu.setAttribute('aria-expanded', String(ouvert));
      boutonMenu.textContent = ouvert ? '✕ Fermer' : '☰ Menu';
    });

    // Fermer le menu après un clic sur un lien
    navigation.querySelectorAll('a').forEach(function (lien) {
      lien.addEventListener('click', function () {
        navigation.classList.remove('ouvert');
        boutonMenu.setAttribute('aria-expanded', 'false');
        boutonMenu.textContent = '☰ Menu';
      });
    });
  }


 

  const carrousel = document.querySelector('.carrousel');
  const slides = document.querySelectorAll('.slide');
  const precedent = document.getElementById('precedent');
  const suivant = document.getElementById('suivant');
  const compteur = document.getElementById('compteur-slide');

  let photoActuelle = 0;
  let points = null;

  
  function afficherPhoto(numero) {
    if (slides.length === 0) return;

    photoActuelle = (numero + slides.length) % slides.length;

    slides.forEach(function (photo, index) {
      photo.classList.toggle('actif', index === photoActuelle);
    });

    if (compteur) {
      compteur.textContent = 'Photo ' + (photoActuelle + 1) + ' sur ' + slides.length;
    }

    if (points) {
      points.querySelectorAll('button').forEach(function (point, index) {
        point.classList.toggle('actif', index === photoActuelle);
        point.setAttribute('aria-pressed', String(index === photoActuelle));
      });
    }
  }

  if (slides.length > 0 && carrousel) {

   
    if (precedent) {
      precedent.setAttribute('aria-label', 'Photo précédente');
      precedent.addEventListener('click', function () {
        afficherPhoto(photoActuelle - 1);
      });
    }

    if (suivant) {
      suivant.setAttribute('aria-label', 'Photo suivante');
      suivant.addEventListener('click', function () {
        afficherPhoto(photoActuelle + 1);
      });
    }

    
    points = document.createElement('div');
    points.className = 'points-carrousel';
    points.setAttribute('aria-label', 'Choisir une photo');

    slides.forEach(function (slide, index) {
      const point = document.createElement('button');
      point.type = 'button';
      point.setAttribute('aria-label', 'Afficher la photo ' + (index + 1));
      point.addEventListener('click', function () {
        afficherPhoto(index);
      });
      points.appendChild(point);
    });

    carrousel.insertAdjacentElement('afterend', points);

    afficherPhoto(0);

    
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      let pauseSurvol = false;
      let pauseFocus = false;

     
      carrousel.addEventListener('mouseenter', function () { pauseSurvol = true; });
      carrousel.addEventListener('mouseleave', function () { pauseSurvol = false; });
      carrousel.addEventListener('focusin', function () { pauseFocus = true; });
      carrousel.addEventListener('focusout', function (e) {
        if (!carrousel.contains(e.relatedTarget)) pauseFocus = false;
      });

    
      setInterval(function () {
        if (!pauseSurvol && !pauseFocus && !document.hidden) {
          afficherPhoto(photoActuelle + 1);
        }
      }, 5500);
    }
  }





  const boutonsFiltre = document.querySelectorAll('.filtre');
  const cartesCours = document.querySelectorAll('.cours article');

  boutonsFiltre.forEach(function (bouton) {
    bouton.addEventListener('click', function () {
      const filtre = bouton.dataset.filtre;
      let nombre = 0;

      
      boutonsFiltre.forEach(function (b) { b.classList.remove('actif'); });
      bouton.classList.add('actif');

     
      cartesCours.forEach(function (carte) {
        const visible = filtre === 'tous' || carte.dataset.categorie === filtre;
        carte.hidden = !visible;
        if (visible) nombre++;
      });

      
      const info = document.getElementById('nombre-cours');
      if (info) {
        info.textContent = nombre + ' cours disponible' + (nombre > 1 ? 's' : '');
      }
    });
  });


  cartesCours.forEach(function (carte) {
    carte.classList.add('carte-animee');
  });


  



  const selectJour = document.getElementById('jour-planning');
  const tablePlanning = document.querySelector('#agenda table');
  const infoPlanning = document.getElementById('info-planning');

  
  function changerJour() {
    if (!selectJour || !tablePlanning) return;

    const jour = selectJour.value;

    tablePlanning.querySelectorAll('tr').forEach(function (ligne) {
      Array.from(ligne.children).forEach(function (cellule, index) {
        cellule.hidden = jour !== 'tous' && index !== 0 && index !== Number(jour);
      });
    });

    if (infoPlanning) {
      infoPlanning.textContent = jour === 'tous'
        ? 'Planning complet du lundi au samedi.'
        : 'Horaires du ' + selectJour.options[selectJour.selectedIndex].text.toLowerCase() + '.';
    }
  }

  if (selectJour) {
    selectJour.addEventListener('change', changerJour);

    document.getElementById('reinitialiser-planning').addEventListener('click', function () {
      selectJour.value = 'tous';
      changerJour();
    });
  }


 

  const formulaireReservation = document.getElementById('form-reservation');

  if (formulaireReservation) {
    const choixCours = document.getElementById('cours');
    const choixDate = document.getElementById('date');
    const nombrePersonnes = document.getElementById('personnes');
    const remise = document.getElementById('etudiant');
    const locationTapis = document.getElementById('location');
    const totalEstime = document.getElementById('total-estime');
    const liste = document.getElementById('liste-recap');
    const message = document.getElementById('message-recap');

  
    const prix = { mat: 18, reformer: 28, prenatal: 20, particulier: 60 };

   
    const aujourdHui = new Date();
    const dateLocale = new Date(aujourdHui.getTime() - aujourdHui.getTimezoneOffset() * 60000);
    choixDate.min = dateLocale.toISOString().slice(0, 10);


    const coursLien = new URLSearchParams(window.location.search).get('cours');
    if (Object.prototype.hasOwnProperty.call(prix, coursLien)) {
      choixCours.value = coursLien;
    }

  
    function ajouterLigne(texte) {
      const ligne = document.createElement('li');
      ligne.textContent = texte;
      liste.appendChild(ligne);
    }

  
    function afficherRecapitulatif() {
      const personnes = Math.max(1, Math.min(6, Number(nombrePersonnes.value) || 1));

      let montant = (prix[choixCours.value] || 0) * personnes;
      if (remise.checked) montant = montant * 0.8;
      if (locationTapis.checked) montant += 2 * personnes;

      totalEstime.textContent = 'Total estimé : ' + montant.toFixed(2).replace('.', ',') + ' €';
      liste.innerHTML = '';

      if (!choixCours.value) {
        message.textContent = 'Choisissez un cours pour voir votre estimation.';
        return;
      }

      message.textContent = 'Aperçu de votre demande (aucune réservation envoyée).';

      const nom = document.getElementById('nom').value.trim();
      const prenom = document.getElementById('prenom').value.trim();
      if (nom || prenom) ajouterLigne('Nom : ' + prenom + ' ' + nom);

      ajouterLigne('Cours : ' + choixCours.options[choixCours.selectedIndex].text);

      if (choixDate.value) {
        ajouterLigne('Date : ' + choixDate.value.split('-').reverse().join('/'));
      }

      const horaire = formulaireReservation.querySelector('input[name="creneau"]:checked');
      if (horaire) ajouterLigne('Horaire : ' + horaire.value);

      ajouterLigne('Personnes : ' + personnes);

      if (remise.checked) ajouterLigne('Remise étudiante : -20 % sur le cours');
      if (locationTapis.checked) ajouterLigne('Location de tapis : +2 € par personne');
    }

    formulaireReservation.addEventListener('input', afficherRecapitulatif);
    formulaireReservation.addEventListener('change', afficherRecapitulatif);


    formulaireReservation.addEventListener('submit', function (evenement) {
      evenement.preventDefault();

      if (!formulaireReservation.reportValidity()) return;

      if (choixDate.value < choixDate.min) {
        choixDate.setCustomValidity('Veuillez choisir une date à venir.');
        choixDate.reportValidity();
        return;
      }

      afficherRecapitulatif();
      message.textContent = 'Votre demande est complète ! Ceci est une démonstration : elle n’a pas été envoyée.';
      document.getElementById('recapitulatif').scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    
    choixDate.addEventListener('input', function () {
      choixDate.setCustomValidity('');
    });

   
    formulaireReservation.addEventListener('reset', function () {
      setTimeout(afficherRecapitulatif, 0);
    });

    afficherRecapitulatif();
  }





  const formulaireContact = document.getElementById('form-contact');

  if (formulaireContact) {
    const texteMessage = document.getElementById('message');
    const compteurMessage = document.getElementById('compteur-message');
    const retour = document.getElementById('message-contact');

   
    function actualiserCompteur() {
      compteurMessage.textContent = texteMessage.value.length + ' / 500 caractères';
    }

    texteMessage.addEventListener('input', actualiserCompteur);

    
    formulaireContact.addEventListener('submit', function (evenement) {
      evenement.preventDefault();

      if (!formulaireContact.reportValidity()) return;

      retour.textContent = 'Merci ' + document.getElementById('nom').value.trim() + ' ! Votre message a bien été rempli. Il n’est pas envoyé (site de démonstration).';
    });

  
    formulaireContact.addEventListener('reset', function () {
      setTimeout(actualiserCompteur, 0);
      retour.textContent = '';
    });

    actualiserCompteur();
  }


 

  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const observateur = new IntersectionObserver(function (elements) {
      elements.forEach(function (element) {
        if (element.isIntersecting) {
          element.target.classList.add('visible');
          observateur.unobserve(element.target);
        }
      });
    }, { threshold: 0.08 });

    document.querySelectorAll('main section').forEach(function (section) {
      section.classList.add('apparition');
      observateur.observe(section);
    });
  }


  

 
  const progression = document.createElement('div');
  progression.className = 'progression-scroll';
  progression.setAttribute('aria-hidden', 'true');
  document.body.appendChild(progression);


  const retourHaut = document.createElement('button');
  retourHaut.type = 'button';
  retourHaut.className = 'retour-haut';
  retourHaut.textContent = '↑';
  retourHaut.setAttribute('aria-label', 'Revenir en haut de page');
  retourHaut.title = 'Retour en haut';
  document.body.appendChild(retourHaut);

  retourHaut.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  
  function actualiserDefilement() {
    const hauteur = document.documentElement.scrollHeight - window.innerHeight;
    const pourcentage = hauteur > 0 ? (window.scrollY / hauteur) * 100 : 0;

    progression.style.width = Math.min(100, pourcentage) + '%';
    retourHaut.classList.toggle('afficher', window.scrollY > 450);
    document.querySelector('header').classList.toggle('header-defile', window.scrollY > 30);
  }

  window.addEventListener('scroll', actualiserDefilement, { passive: true });
  window.addEventListener('resize', actualiserDefilement);
  actualiserDefilement();




  const photosGalerie = document.querySelectorAll('.galerie-grid img');

  if (photosGalerie.length) {

  
    const visionneuse = document.createElement('div');
    visionneuse.className = 'visionneuse';
    visionneuse.setAttribute('role', 'dialog');
    visionneuse.setAttribute('aria-modal', 'true');
    visionneuse.setAttribute('aria-label', 'Photo agrandie');
    visionneuse.hidden = true;
    visionneuse.innerHTML = '<button class="fermer-visionneuse" type="button" aria-label="Fermer la photo">×</button><img alt=""><p></p>';
    document.body.appendChild(visionneuse);

    const photoAgrandie = visionneuse.querySelector('img');
    const legende = visionneuse.querySelector('p');
    const fermer = visionneuse.querySelector('button');
    let dernierePhoto = null;


    function fermerPhoto() {
      visionneuse.hidden = true;
      document.body.classList.remove('sans-scroll');
      if (dernierePhoto) dernierePhoto.focus();
    }

    fermer.addEventListener('click', fermerPhoto);

    visionneuse.addEventListener('click', function (e) {
      if (e.target === visionneuse) fermerPhoto();
    });

    document.addEventListener('keydown', function (e) {
      if (!visionneuse.hidden && e.key === 'Escape') fermerPhoto();
    });


    photosGalerie.forEach(function (photo) {
      photo.setAttribute('tabindex', '0');
      photo.setAttribute('role', 'button');
      photo.setAttribute('aria-label', 'Agrandir : ' + photo.alt);

      function ouvrirPhoto() {
        dernierePhoto = photo;
        photoAgrandie.src = photo.src;
        photoAgrandie.alt = photo.alt;
        legende.textContent = photo.alt;
        visionneuse.hidden = false;
        document.body.classList.add('sans-scroll');
        fermer.focus();
      }

      photo.addEventListener('click', ouvrirPhoto);

      photo.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          ouvrirPhoto();
        }
      });
    });
  }




  const questions = document.querySelectorAll('.faq-liste details');

  questions.forEach(function (question) {
    question.addEventListener('toggle', function () {
      if (question.open) {
        questions.forEach(function (autre) {
          if (autre !== question) autre.open = false;
        });
      }
    });
  });


  

  
  const video = document.querySelector('.video-container video');

  if (video) {
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && !video.paused) video.pause();
    });
  }

});
